% Dagligt antal transporter fra afdeling til afdeling
Tr = [0    40     0    19    34
      7     0     0    23    22
      1    38     0    16     0
      0     0     0     0     0
     18    31     0    28     0];
   
% Transportafstande (m) fra lokale til lokale
Dst = [ 0   104    45   132    44
       83     0   135    28   125
       45    77     0    13    51
       81    28    65     0    33
       44    35    51    33     0];