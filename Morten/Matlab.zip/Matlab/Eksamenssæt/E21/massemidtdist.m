function d = massemidtdist(m,r)
n = length(m);
M = sum(m);
delta = <UDFYLD>;
sum_mx = <UDFYLD>;
sum_my = <UDFYLD>;
for i = 1:n
  <UDFYLD 1,2,... LINJER>
end
xc = sum_mx/M;
yc = sum_my/M;
d = <UDFYLD>;

