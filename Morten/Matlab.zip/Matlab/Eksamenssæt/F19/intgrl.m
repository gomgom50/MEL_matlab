function I = intgrl(f,a,b,n)
h = (b-a)/n;
t = <UDFYLD>;
y = <UDFYLD>;
I = <UDFYLD>;