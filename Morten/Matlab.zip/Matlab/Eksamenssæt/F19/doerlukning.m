eps = 1;              % Grad
a = 1.69; b = -0.71;
dt = 0.1;             % Sekunder
y(1) = 83; y(2) = 82; % Grader
t(1) = 0;  t(2) = dt; % Sekunder
i = 2;
while <UDFYLD>
  i = <UDFYLD>;
  y(i) = <UDFYLD>;
  t(i) = <UDFYLD>;
  <UDFYLD>
end
plot(t,y)
xlabel('t (s)'), ylabel('y (gr.)')