function stat = kaststat(kast)
<UDFYLD>
stat = zeros(1,6);
for <UDFYLD>
  <UDFYLD>
end