clear, format long
p = @(x) 0.4*x^5 - x^4 - 6*x^3 + 2*x^2 + 16*x + 7;
pdiff = @(x) 2*x^4 - 4*x^3 - 18*x^2 + 4*x + 16;
x = <UDFYLD>;
disp(x)
for i = 1:<UDFYLD>
  x = <UDFYLD>;
  disp(x)
end